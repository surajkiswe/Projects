#!C:\Users\suraj\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()

try:
    reqobj=cgi.FieldStorage()
    pid=reqobj.getvalue("pid")
    mnm=reqobj.getvalue("mnm")
    cmp=reqobj.getvalue("cmp")
    clrtech=reqobj.getvalue("clrtech")
    ram=reqobj.getvalue("ram")
    rom=reqobj.getvalue("rom")
    clr=reqobj.getvalue("clr")
    scrn=reqobj.getvalue("scrn")
    bat=reqobj.getvalue("bat")
    pcr=reqobj.getvalue("pcr")
    prc=reqobj.getvalue("prc")
    rt=reqobj.getvalue("rt")

    con=pymysql.connect(host='bhmacmsjsimpkiljjnab-mysql.services.clever-cloud.com',user='ufydbghpaebd6v1n',password='0IjlotKAgSVDmNJ5QxRT',database='bhmacmsjsimpkiljjnab')
    curs=con.cursor()
    curs.execute("insert into MOBILES values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(pid,mnm,cmp,clrtech,ram,rom,clr,scrn,bat,pcr,prc,rt))
    con.commit()
    print("<h2 style='color: Green;'>Mobile added sucessfully</h2><hr>")
    print("<a href='MobileWorld.html'>Home</a>")
except Exception as e:
    print('error',e)